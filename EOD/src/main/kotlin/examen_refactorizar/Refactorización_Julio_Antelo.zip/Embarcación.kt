package examen_refactorizar

abstract open class Embarcación(plazas:Int,) {

    override fun toString(): String {
        return TODO("Provide the return value")
    }
    protected open fun CalcularCosteTotal(horas:Int):Int{
        return TODO("Provide the return value")
    }
}
