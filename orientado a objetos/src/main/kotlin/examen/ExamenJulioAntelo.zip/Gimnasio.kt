package examen

class Gimnasio(nombre:String,Direccion:String, listaPersonas:MutableList<Persona>) {

}